package ar.edu.centro8.ejercicio2.servlets;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/calculadora")
public class CalculadoraServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        double num1 = Integer.parseInt(req.getParameter("num1"));
        double num2 = Integer.parseInt(req.getParameter("num2"));
        String op = req.getParameter("op");
        double resultado;

        switch (op) {
            case "*":
                resultado = (double) (num1 * num2);
                resp.getWriter().print(resultado);
                break;
            case "/":
                if (num2 == 0) {
                    resp.getWriter().print("No es posible hacer divisiones por cero en esta parte de la matrix, le recomendamos no volver a intentarlo.");
                } else {
                    resultado = (num1 / num2);
                    resp.getWriter().print(resultado);
                }
                break;
            case "-":
                resultado = (num1 - num2);
                resp.getWriter().print(resultado);
                break;
            case "+":
                resultado = (num1 + num2);
                resp.getWriter().println(resultado);
                break;
            default:
            resp.getWriter().println("El operador seleccionado no es un operador válido.");
            break;


        }

    }
}

